#include <iostream>
#include <fstream>
#include <sstream>
#include <unordered_map>
#include <vector>
#include <algorithm>

using namespace std;

// Struct to represent a course
struct Course {
    string courseID;
    string courseName;
    vector<string> preList;
};

// Function to read and parse the CSV file
unordered_map<string, Course> txtParser(const string& filePath) {
    unordered_map<string, Course> courseMap;
    ifstream file(filePath);
    string line;

    if (!file.is_open()) {
        cout << "Error opening file. Please check the filename and try again.\n";
        return courseMap;
    }

    while (getline(file, line)) {
        stringstream ss(line);
        string token;
        vector<string> tokens;

        while (getline(ss, token, ',')) {
            tokens.push_back(token);
        }

        if (tokens.size() >= 2) {
            Course newCourse;
            newCourse.courseID = tokens[0];
            newCourse.courseName = tokens[1];

            for (size_t i = 2; i < tokens.size(); ++i) {
                newCourse.preList.push_back(tokens[i]);
            }

            courseMap[newCourse.courseID] = newCourse;
        }
    }

    file.close();
    return courseMap;
}

// Function to print a single course's information
void printCourse(const unordered_map<string, Course>& courses, const string& courseID) {
    auto it = courses.find(courseID);
    if (it == courses.end()) {
        cout << "Course not found.\n";
        return;
    }

    const Course& course = it->second;
    cout << course.courseID << ", " << course.courseName << endl;

    if (course.preList.empty()) {
        cout << "Prerequisites: None\n";
    }
    else {
        cout << "Prerequisites: ";
        for (size_t i = 0; i < course.preList.size(); ++i) {
            cout << course.preList[i];
            if (i != course.preList.size() - 1) cout << ", ";
        }
        cout << endl;
    }
}

// Function to print all courses in alphanumeric order
void printCourseList(const unordered_map<string, Course>& courses) {
    vector<string> sortedKeys;
    for (const auto& pair : courses) {
        sortedKeys.push_back(pair.first);
    }

    sort(sortedKeys.begin(), sortedKeys.end());

    cout << "\nHere is a sample schedule:\n";
    for (const string& key : sortedKeys) {
        cout << key << ", " << courses.at(key).courseName << endl;
    }
}

// Main menu and program loop
int main() {
    unordered_map<string, Course> courses;
    bool loaded = false;
    int choice;

    cout << "Welcome to the course planner.\n";

    while (true) {
        cout << "\n1. Load Data Structure\n";
        cout << "2. Print Course List\n";
        cout << "3. Print Course\n";
        cout << "9. Exit\n";
        cout << "What would you like to do? ";
        if (!(cin >> choice)) {
            cin.clear();
            cin.ignore(10000, '\n');
            cout << "Invalid input. Please enter a number (1, 2, 3, or 9).\n";
            continue;
        }

        if (choice == 1) {
            string filename;
            cout << "Enter the file name: ";
            cin.ignore(); // Clear leftover newline
            getline(cin, filename); // Capture full line with spaces
            courses = txtParser(filename);
            if (!courses.empty()) {
                loaded = true;
                cout << "Courses loaded successfully.\n";
            }
        }
        else if (choice == 2) {
            if (!loaded) {
                cout << "Please load data first.\n";
            }
            else {
                printCourseList(courses);
            }
        }
        else if (choice == 3) {
            if (!loaded) {
                cout << "Please load data first.\n";
            }
            else {
                string courseID;
                cout << "What course do you want to know about? ";
                cin >> courseID;
                // Convert input to uppercase to match data
                transform(courseID.begin(), courseID.end(), courseID.begin(), ::toupper);
                printCourse(courses, courseID);
            }
        }
        else if (choice == 9) {
            cout << "Thank you for using the course planner!\n";
            break;
        }
        else {
            cout << choice << " is not a valid option.\n";
        }
    }

    return 0;
}
